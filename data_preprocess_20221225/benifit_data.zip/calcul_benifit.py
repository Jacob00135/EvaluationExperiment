import pandas as pd
import numpy as np

our_ADNI = pd.read_csv('ADNI.csv')
features = our_ADNI.columns.tolist()
#文静整理的数据

Dementia_benifit_test = pd.read_csv('./train_test/Dementia_benifit_test.csv')
Dementia_benifit_test = Dementia_benifit_test.loc[:, ['RID','VISCODE']]

Dementia_benifit_train = pd.read_csv('./train_test/Dementia_benifit_train.csv')
Dementia_benifit_train = Dementia_benifit_train.loc[:, ['RID','VISCODE']]

MCI_benifit_test = pd.read_csv('./train_test/MCI_benifit_test.csv')
MCI_benifit_test = MCI_benifit_test.loc[:, ['RID','VISCODE']]

MCI_benifit_train = pd.read_csv('./train_test/MCI_benifit_train.csv')
MCI_benifit_train = MCI_benifit_train.loc[:, ['RID','VISCODE']]

#开始Merge
our_Dementia_benifit_test = pd.merge(our_ADNI, Dementia_benifit_test, on=['RID','VISCODE'])
our_Dementia_benifit_test = our_Dementia_benifit_test.loc[:, features]
our_Dementia_benifit_test.to_csv('./our_benifit_data/our_Dementia_benifit_test.csv', index=0)

our_Dementia_benifit_train = pd.merge(our_ADNI, Dementia_benifit_train, on=['RID','VISCODE'])
our_Dementia_benifit_train = our_Dementia_benifit_train.loc[:, features]
our_Dementia_benifit_train.to_csv('./our_benifit_data/our_Dementia_benifit_train.csv', index=0)

our_MCI_benifit_test = pd.merge(our_ADNI, MCI_benifit_test, on=['RID','VISCODE'])
our_MCI_benifit_test = our_MCI_benifit_test.loc[:, features]
our_MCI_benifit_test.to_csv('./our_benifit_data/our_MCI_benifit_test.csv', index=0)

our_MCI_benifit_train = pd.merge(our_ADNI, MCI_benifit_train, on=['RID','VISCODE'])
our_MCI_benifit_train = our_MCI_benifit_train.loc[:, features]
our_MCI_benifit_train.to_csv('./our_benifit_data/our_MCI_benifit_train.csv', index=0)

#no benifit data
cn_test = pd.read_csv('./train_test/cn_test.csv')
cn_test = cn_test.loc[:, ['RID','VISCODE']]

cn_train = pd.read_csv('./train_test/cn_train.csv')
cn_train = cn_train.loc[:, ['RID','VISCODE']]

Dementia_no_benifit_test = pd.read_csv('./train_test/Dementia_no_benifit_test.csv')
Dementia_no_benifit_test = Dementia_no_benifit_test.loc[:, ['RID','VISCODE']]

Dementia_no_benifit_train = pd.read_csv('./train_test/Dementia_no_benifit_train.csv')
Dementia_no_benifit_train = Dementia_no_benifit_train.loc[:, ['RID','VISCODE']]

MCI_no_benifit_test = pd.read_csv('./train_test/MCI_no_benifit_test.csv')
MCI_no_benifit_test = MCI_no_benifit_test.loc[:, ['RID','VISCODE']]

MCI_no_benifit_train = pd.read_csv('./train_test/MCI_no_benifit_train.csv')
MCI_no_benifit_train = MCI_no_benifit_train.loc[:, ['RID','VISCODE']]

#开始Merge
our_cn_test = pd.merge(our_ADNI, cn_test, on=['RID','VISCODE'])
our_cn_test = our_cn_test.loc[:, features]
our_cn_test.to_csv('./our_benifit_data/our_cn_test.csv', index=0)

our_cn_train = pd.merge(our_ADNI, cn_train, on=['RID','VISCODE'])
our_cn_train = our_cn_train.loc[:, features]
our_cn_train.to_csv('./our_benifit_data/our_cn_train.csv', index=0)

our_Dementia_no_benifit_test = pd.merge(our_ADNI, Dementia_no_benifit_test, on=['RID','VISCODE'])
our_Dementia_no_benifit_test = our_Dementia_no_benifit_test.loc[:, features]
our_Dementia_no_benifit_test.to_csv('./our_benifit_data/our_Dementia_no_benifit_test.csv', index=0)

our_Dementia_no_benifit_train = pd.merge(our_ADNI, Dementia_no_benifit_train, on=['RID','VISCODE'])
our_Dementia_no_benifit_train = our_Dementia_no_benifit_train.loc[:, features]
our_Dementia_no_benifit_train.to_csv('./our_benifit_data/our_Dementia_no_benifit_train.csv', index=0)

our_MCI_no_benifit_test = pd.merge(our_ADNI, MCI_no_benifit_test, on=['RID','VISCODE'])
our_MCI_no_benifit_test = our_MCI_no_benifit_test.loc[:, features]
our_MCI_no_benifit_test.to_csv('./our_benifit_data/our_MCI_no_benifit_test.csv', index=0)

our_MCI_no_benifit_train = pd.merge(our_ADNI, MCI_no_benifit_train, on=['RID','VISCODE'])
our_MCI_no_benifit_train = our_MCI_no_benifit_train.loc[:, features]
our_MCI_no_benifit_train.to_csv('./our_benifit_data/our_MCI_no_benifit_train.csv', index=0)